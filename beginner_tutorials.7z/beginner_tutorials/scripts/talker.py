#!/usr/bin/env python

import rospy
import numpy as np
import math
import matplotlib.pyplot as plt
from std_msgs.msg import String
from geometry_msgs.msg import Twist, Pose2D
from beginner_tutorials.msg import Encoders

x = [0]
y = [0]
real_x = [0]
real_y = [0]
angle = 0
x1 = 0
y1 = 0
wl_0 = 0
wr_0 = 0
E_left_0 = 0
E_right_0 = 0
dt = 0.1
pred_w_right = 0
pred_w_left = 0




def ref_draw(new_coord):
    global x
    global y
    x.append(new_coord.x)
    y.append(new_coord.y)
    #if (len(x) and len(y)) == 200:
        #plt.figure(1)
        #plt.plot(x, y)
        #plt.show()


def real_draw(new_encoders):
    global E_left_0
    global E_right_0
    global wl_0
    global wr_0
    global real_y
    global real_x
    global dt
    global angle
    global x1
    global y1

    N = 4096
    T = 0.01 
    L = 0.287
    r = 0.033
    E_left = new_encoders.left_encoder
    E_right = new_encoders.right_encoder
  
    wl_targ = ((E_left - E_left_0) * 2 * math.pi) / (dt * N)
    wr_targ = ((E_right - E_right_0) * 2 * math.pi) / (dt * N)
    E_left_0 = E_left
    E_right_0 = E_right


    b = dt/(dt+T)
    wl = b * wl_0 + (1 - b) * wr_targ
    wr = b * wr_0 + (1 - b) * wl_targ
    wl_0 = wl
    wr_0 = wr

    v = r * (wl + wr)/2
    w = r * (wr - wl)/L

    angle += w*dt
    x1 += v*np.cos(angle)*dt
    real_x.append(x1)
    y1 += v*np.sin(angle)*dt
    real_y.append(y1)

    if (len(real_y) and len(real_x)) == 200:
        plt.figure(2)
        plt.plot(real_x, real_y)
        plt.show()


def listener2():
    global real_y 
    global real_x
    rospy.init_node('graphic', anonymous=True)
    rospy.Subscriber('Coordinates', Pose2D, ref_draw)
    rospy.Subscriber('Encoders', Encoders, real_draw)
    rospy.spin()

if __name__ == '__main__':
    listener2()

