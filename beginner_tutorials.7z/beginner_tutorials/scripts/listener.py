#!/usr/bin/env python
import math
import rospy
import numpy as np
from std_msgs.msg import String 
from geometry_msgs.msg import Twist, Pose2D
from beginner_tutorials.msg import Encoders

angle = 0
x_coord = 0
y_coord = 0
dt = 0.1

E_left_0 = 0
E_right_0 = 0

def callback(twist):
    global now
    v = twist.linear.x
    w = twist.angular.z 
    ref_coordinates(v, w, dt)
    count_encoders(v, w, dt) 


def count_encoders(v, w, dt):
    global E_left_0
    global E_right_0

    global now
    global new_encoders
    N = 4096
    L = 0.287
    R = 0
    r = 0.033
    if w !=0:
	R = v/w
    w_left = (R - 0.5*L)*w/r
    w_right = (R + 0.5*L)*w/r
    #rospy.loginfo('left encoder %s\t right encoder %s' % (w_left, w_right))
    E_left = w_left*dt*N/2*math.pi + E_left_0
    E_right = w_right*dt*N/2*math.pi + E_right_0
    E_left_0 = E_left
    E_right_0 = E_right


    new_encoders.header.stamp = rospy.Time.now()
    new_encoders.left_encoder = int(E_left)
    new_encoders.right_encoder = int(E_right)
    
    rate = rospy.Rate(10) 
#    while rospy.Time.now() < now + rospy.Duration.from_sec(20):	
    pub_encoders.publish(new_encoders) 
    rospy.loginfo('time: %s\t left encoder %s\t right encoder %s' % (new_encoders.header.stamp, new_encoders.left_encoder, new_encoders.right_encoder))
    rate.sleep()



def ref_coordinates(v, w, dt):
    global x_coord
    global y_coord
    global angle
    global new_coord

    angle += w*dt
    x_coord += v*np.cos(angle)*dt
    y_coord += v*np.sin(angle)*dt
    new_coord.x = x_coord
    new_coord.y = y_coord
    pub_coord.publish(new_coord)
    #rospy.loginfo('left encoder %s\t right encoder %s' % (new_coord.x, new_coord.y))

def listener():
    rospy.Subscriber('cmd_vel', Twist, callback)
    rospy.spin()

if __name__ == '__main__':
    rospy.init_node('listener', anonymous=True)
    now = rospy.Time.now()
    pub_encoders = rospy.Publisher('Encoders', Encoders, queue_size = 10)
    new_encoders = Encoders()
    pub_coord = rospy.Publisher('Coordinates', Pose2D, queue_size = 10)
    new_coord = Pose2D()

    listener()

